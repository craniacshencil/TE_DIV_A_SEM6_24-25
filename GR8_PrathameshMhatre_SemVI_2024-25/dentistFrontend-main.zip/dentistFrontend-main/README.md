# Dentist Frontend

step 1: `npm i` //install all dependencies

step 2: Create the `.env.local` and `.env.production` env files using the examples

step 2: `npm run dev `
